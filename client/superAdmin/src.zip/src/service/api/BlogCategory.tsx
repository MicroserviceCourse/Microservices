// client/superAdmin/src/service/api/BlogCategory.ts

import http from "../http/http"; // giống các file Module.tsx, Role.tsx

import type {
  ApiResponse,
  PageResponse,
  CategoryDto,
  CategoryQuery,
} from "../../types";

// prefix này tuỳ anh map ở API Gateway
// nếu gateway map là /blogservice/** thì ok, còn không thì sửa lại cho đúng
const BASE_URL = "/blogservice/api/v1/categories";

export const BlogCategoryApi = {
  async getPage(params: CategoryQuery) {
    const res = await http.get<ApiResponse<PageResponse<CategoryDto>>>(BASE_URL, {
      params,
    });
    // backend ApiResponse<T> => { data: T, ... }
    return res.data.data;
  },

  async getById(id: number) {
    const res = await http.get<ApiResponse<CategoryDto>>(`${BASE_URL}/${id}`);
    return res.data.data;
  },

  async create(payload: Omit<CategoryDto, "id" | "slug">) {
    // backend chỉ cần name, description; slug backend tự sinh
    const res = await http.post<ApiResponse<CategoryDto>>(BASE_URL, payload);
    return res.data.data;
  },

  async update(id: number, payload: Partial<Omit<CategoryDto, "id">>) {
    const res = await http.put<ApiResponse<CategoryDto>>(
      `${BASE_URL}/${id}`,
      payload,
    );
    return res.data.data;
  },

  async delete(id: number) {
    await http.delete<ApiResponse<void>>(`${BASE_URL}/${id}`);
  },
};
