// client/superAdmin/src/pages/blog/category/CreateCategory.tsx

import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import { BlogCategoryApi } from "../../../service/api/BlogCategory";
import type { CategoryDto } from "../../../types";

const BlogCreateCategory = () => {
  const { id } = useParams<{ id: string }>();
  const isEdit = Boolean(id);

  const [form, setForm] = useState<Partial<CategoryDto>>({
    name: "",
    description: "",
  });
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    if (!isEdit) return;

    const loadDetail = async () => {
      try {
        setLoading(true);
        const data = await BlogCategoryApi.getById(Number(id));
        setForm({
          name: data.name,
          description: data.description,
        });
      } catch (error) {
        console.error("Load category detail error", error);
      } finally {
        setLoading(false);
      }
    };

    loadDetail();
  }, [id, isEdit]);

  const handleChange =
    (field: keyof CategoryDto) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      setForm((prev) => ({ ...prev, [field]: e.target.value }));
    };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name) {
      alert("Name is required");
      return;
    }

    try {
      setLoading(true);
      if (isEdit) {
        await BlogCategoryApi.update(Number(id), {
          name: form.name!,
          description: form.description,
        });
      } else {
        await BlogCategoryApi.create({
          name: form.name!,
          description: form.description,
          slug: "", // backend tự generate, có thể bỏ field này trong Omit
          id: 0,    // không dùng, chỉ để satisfy type nếu cần
        } as any);
      }

      navigate("/admin/blog/categories");
    } catch (error) {
      console.error("Save category error", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto p-4">
      <h1 className="text-xl font-semibold mb-4">
        {isEdit ? "Edit Blog Category" : "Create Blog Category"}
      </h1>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1 font-medium">Name</label>
          <input
            className="w-full border px-3 py-2 rounded"
            value={form.name || ""}
            onChange={handleChange("name")}
          />
        </div>

        <div>
          <label className="block mb-1 font-medium">Description</label>
          <textarea
            className="w-full border px-3 py-2 rounded"
            rows={4}
            value={form.description || ""}
            onChange={handleChange("description")}
          />
        </div>

        <div className="flex gap-2 justify-end">
          <button
            type="button"
            className="px-4 py-2 border rounded"
            onClick={() => navigate("/admin/blog/categories")}
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50"
          >
            {loading ? "Saving..." : "Save"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default BlogCreateCategory;
